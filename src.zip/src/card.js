import React from "react";


function Card(props) {

    return(
        <div className="main" style={{width:'20rem',border:'5px solid Black',margin:'0px auto',marginTop:'30px',}}>
            <img  width='100%'  src={props.imageurl} />
            <h1 style={{fontFamily:'Times New Roman'}}> {props.title}</h1>
            <p> {props.all}</p>

        </div>
    )
    
}

export default Card;