import logo from './logo.svg';
import './App.css';
import Card from './card';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Card title='SHIRTS' all='Best Quality shirts.' imageurl='https://thumbs.gfycat.com/VigorousDisloyalCoelacanth-size_restricted.gif'/> 
      <Card title='Kurta Pajama' all='Unique Design Kurta Pajama.' imageurl='https://i.pinimg.com/originals/64/f8/c8/64f8c83d521812ba5e79965ec6678dad.gif'/>
      <Card title='Jeans Jacket' all='Best Quality Jacket' imageurl='https://images.squarespace-cdn.com/content/v1/5c53c3e43560c322f03e43cf/1613781964048-OVYNHTQQQG2NRNTP2N6O/3D-JACKET-DENIM-FULL-SPIN.gif'/>

    </div>
  );
}

export default App;
